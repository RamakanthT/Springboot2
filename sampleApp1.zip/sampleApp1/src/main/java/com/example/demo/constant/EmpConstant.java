package com.example.demo.constant;

public class EmpConstant {

	public static final String EMP_USER1 = "emp1";
	public static final String EMP_PWD1 = "pwd1";
	public static final String EMP_USER2 = "emp2";
	public static final String EMP_PWD2 = "pwd2";
	public static final String EMP_USER3 = "emp3";
	public static final String EMP_PWD3 = "pwd3";
	
}
